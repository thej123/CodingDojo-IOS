//
//  NSFWDelegate.swift
//  NESW
//
//  Created by Thej on 9/12/17.
//  Copyright © 2017 Thej. All rights reserved.
//

import UIKit

protocol NSFWDelegate: class {
    func cancelButtonPressed(by controller: UIViewController)
}

//
//  ViewController.swift
//  Cold Call 1
//
//  Created by Thej on 9/7/17.
//  Copyright © 2017 Thej. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var nameTextLabel: UILabel!
    
    var nameArr = ["Thej", "Havi", "Harshada", "Jaun", "Tanvi"]
    var track = 0
    
    @IBAction func coldCallButton(_ sender: UIButton) {
        let temp = track
        var index = Int(arc4random_uniform(5))
        track = index
        
        while index == temp {
            index = Int(arc4random_uniform(5))
        }
        nameTextLabel.text = nameArr[index]
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        nameTextLabel.text = nameArr[0]
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

